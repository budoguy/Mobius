/**
 * External to allow main.cpp to filter channels in the SoftDevice API
 */
extern unsigned char CH_37_OFF;
extern unsigned char CH_38_OFF;
extern unsigned char CH_39_OFF;