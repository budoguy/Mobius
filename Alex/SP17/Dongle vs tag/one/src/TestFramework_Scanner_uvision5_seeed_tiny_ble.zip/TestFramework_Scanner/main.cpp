#include "mbed.h"
#include "ble/BLE.h"

// Compile time options
#define BLINK_LED           1 // Whether to blink the LED
#define CYCLE_CHANNELS      0 // Whether to scan cycling between
                              // single channels or normally
#define BAUD_RATE           115200 // baud

// Experiment parameters
#define CYCLE_INTERVAL      5000    // ms; see CYCLE_CHANNELS
#define SCAN_INTERVAL       100     // ms
#define SCAN_WINDOW         SCAN_INTERVAL   // ms; must be <= SCAN_INTERVAL
#define BLINK_INTERVAL      1000    // ms

// Constants
#define NRF_RADIO_FREQUENCY (*(uint32_t*)(0x40001508UL))

BLE& ble = BLE::Instance(BLE::DEFAULT_INSTANCE);

uint8_t channel = 37;

Serial pc(p9, p11);
Timer uptime;


#if BLINK_LED
void blinkCallback(void)
{
    static DigitalOut led(LED1, 1);
    led = !led;
}
#endif

/*
 * This function is called every time we scan an advertisement.
 */
void advertisementCallback(const Gap::AdvertisementCallbackParams_t *params)
{
    if (params->peerAddr[1] == 0xAA &&
        params->peerAddr[2] == 0xAA &&
        params->peerAddr[3] == 0xAA &&
        params->peerAddr[4] == 0xAA &&
        params->peerAddr[5] == 0xAA)
    {
        printf("%d,%d,%d,%d,%d\n",
            params->peerAddr[0],
            params->advertisingData[2],
            uptime.read_ms(),
            params->rssi,
#if CYCLE_CHANNELS
            channel
#else
            params->advertisingData[3] // Infer channel from packet data
#endif
        );
    }
}

void setupScanning(uint8_t channel, uint16_t scanInterval, uint16_t scanWindow)
{
#if CYCLE_CHANNELS
    switch (channel) {
        case 37:
            NRF_RADIO_FREQUENCY = 2; // 2402 MHz
            break;
        case 38:
            NRF_RADIO_FREQUENCY = 26; // 2426 MHz
            break;
        case 39:
            NRF_RADIO_FREQUENCY = 80; // 2480 MHz
            break;
        default:
            break;
    }
#endif
    ble.gap().setScanParams(scanInterval, scanWindow);
    ble.gap().startScan(advertisementCallback);
}

#if CYCLE_CHANNELS
void cycleChannelCallback(void)
{
    switch (channel) {
        case 37:
            channel = 38;
            break;
        case 38:
            channel = 39;
            break;
        case 39:
            channel = 37;
            break;
        default:
            channel = 0;
            break;
    }
    setupScanning(channel, SCAN_INTERVAL, SCAN_WINDOW);
}
#endif

void bleInitCallback(BLE::InitializationCompleteCallbackContext *params)
{
    static Ticker cycleChannelTicker;
    
    if (params->error != BLE_ERROR_NONE ||
        params->ble.getInstanceID() != BLE::DEFAULT_INSTANCE) {
        return;
    }

#if CYCLE_CHANNELS
    setupScanning(channel, SCAN_INTERVAL, SCAN_WINDOW);
    cycleChannelTicker.attach(cycleChannelCallback, CYCLE_INTERVAL/1000.0);
#else
    setupScanning(channel, SCAN_INTERVAL, SCAN_WINDOW);
#endif
}

int main(void)
{
    static Ticker ledTicker, incSeqNumTicker;
    uptime.start();
    
    pc.baud(BAUD_RATE);

#if BLINK_LED
    ledTicker.attach(blinkCallback, BLINK_INTERVAL/1000.0);
#endif

    printf("\nID,Sequence Number,Timestamp,RSSI,Channel\n");
    BLE &ble = BLE::Instance();
    ble.init(bleInitCallback);

    while (true) {
        ble.waitForEvent();
    }
}
